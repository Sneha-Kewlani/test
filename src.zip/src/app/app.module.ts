import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { RouterModule } from '@angular/router';
import {HomeComponent} from './components/HomePage/HomeComponent';
import {NavBarComponent} from './components/NavBar/NavBarComponent';
import {IndexPageComponent} from './components/indexPage';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {PostAdComponent} from './components/PostAdvertisement/PostAdComponent';
import { AdvertisementService } from './services/AdvertisementService';
import {GetAllAdComponent} from './components/GetAllAdvertisement/GetAllAdComponent';
import {EditAdComponent} from './components/EditAdvertisement/EditAdComponent';
import {LoginComponent} from './components/Login/LoginComponent';

@NgModule({
  imports:      [ BrowserModule,FormsModule, ReactiveFormsModule,HttpModule, RouterModule.forRoot([ 
                    {path: '', component: IndexPageComponent},{path: 'EditAd/:i', component: EditAdComponent}
                ])],

  declarations: [ AppComponent,IndexPageComponent, HomeComponent, NavBarComponent, PostAdComponent, 
                  EditAdComponent, GetAllAdComponent, LoginComponent ],

  bootstrap:    [ AppComponent ],
   providers:    [ AdvertisementService ]
})
export class AppModule { }
