import {Component} from '@angular/core';
import { AdvertisementService } from '../../services/AdvertisementService';
import { Router } from '@angular/router';


@Component({
    selector: 'GetAllAdSelector',
    templateUrl: `./GetAllAdComponent.html`,
    styleUrls: [`./GetAllAd.css`]
  
})

export class GetAllAdComponent {

advertisements: Array<any>=[];


    constructor(private as:AdvertisementService, private router:Router ) {
        
}


    onSubmit()
    {
            this.as.getAdvertisements().subscribe((data:any)=>{
            /*for(let item of data.data["mypostList"])
                {
                    let prodObj={name:item.name, title:item.title, category:item.category, description:item.description};
                    this.advertisements.push(prodObj);
                    console.log(prodObj);
                
                }*/
                this.advertisements=data.data["mypostList"];
            });

    }

    deleteObject(index:number){
        let deleteAd:Array<any>=[];
       deleteAd=this.advertisements[index];
       this.as.deleteAdvertisement(deleteAd.id).subscribe((data)=>{
           this.as.getAdvertisements().subscribe((data)=>{
                this.advertisements=data.data["mypostList"];
           });
       });

    }  
    editObject(index:number){
     this.router.navigate(['/EditAd',index]);
    }
    
}
