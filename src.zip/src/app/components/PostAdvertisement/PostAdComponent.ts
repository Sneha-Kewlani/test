import {Component} from '@angular/core';
import { AdvertisementService } from '../../services/AdvertisementService';



@Component({
    selector: 'PostAdSelector',
    templateUrl: `./PostAdComponent.html`,
    styleUrls: [`./PostAd.css`]
})

export class PostAdComponent {

     constructor(private as:AdvertisementService){
            as.getCategory().subscribe((data)=> {  
               for(let item of data.data["itemList"])
                {
                this.options.push(item.name);
                console.log(item.name);
                
                }

            });

            console.log("options: ",this.options);
    }


     /* options = [{ name: 'Furniture', value: 'Furniture' }, 
                { name: 'Cloths', value: 'Cloths' }, 
                { name: 'Mobile', value: 'Mobile' },
                { name: 'Real Estate', value: 'Real Estate' }];*/
    options:Array<any>=[];
     title:any;
     category:any;
     name:any;
     description:any;
     
    onSubmit(title:any, name:any, category:any, description:any) {
        let obj ={title:title, name:name, category:category,description:description};
            //this.prodList.push(obj);
           
        this.as.postAd(obj);
    }
    
}
