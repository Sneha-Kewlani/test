import {Component, OnInit} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AdvertisementService } from '../../services/AdvertisementService';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'EditAdSelector',
    templateUrl: `./EditAdComponent.html`,
    styleUrls: [`./EditAd.css`]
})

export class EditAdComponent implements OnInit {

    constructor(private as:AdvertisementService, private ar:ActivatedRoute){}
    //title = "Add Advertisement";
    options = [{ name: 'Furniture', value: 'Furniture' }, 
                { name: 'Cloths', value: 'Cloths' }, 
                { name: 'Mobile', value: 'Mobile' },
                { name: 'Real Estate', value: 'Real Estate' }];

                index:any;
    editAdForm = new FormGroup({
        title: new FormControl("car", [Validators.required, Validators.minLength(3)]),
        name: new FormControl("sneha", [Validators.required, Validators.minLength(3)]),
        category: new FormControl("Mobile", [Validators.required]),
        description: new FormControl("black", [Validators.required, Validators.minLength(3)]),
    });
    
 
    onSubmit(obj:any) { 
        /*let obj ={title:title, name:name, category:category,description:description};
            //this.prodList.push(obj);
           
        this.as.postAd(obj);*/
        
     } 
     ngOnInit() { this.index = this.ar.snapshot.params['i.value']; } 
    
}
