"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var AdvertisementService_1 = require("../../services/AdvertisementService");
var router_1 = require("@angular/router");
var EditAdComponent = (function () {
    function EditAdComponent(as, ar) {
        this.as = as;
        this.ar = ar;
        //title = "Add Advertisement";
        this.options = [{ name: 'Furniture', value: 'Furniture' },
            { name: 'Cloths', value: 'Cloths' },
            { name: 'Mobile', value: 'Mobile' },
            { name: 'Real Estate', value: 'Real Estate' }];
        this.editAdForm = new forms_1.FormGroup({
            title: new forms_1.FormControl("car", [forms_1.Validators.required, forms_1.Validators.minLength(3)]),
            name: new forms_1.FormControl("sneha", [forms_1.Validators.required, forms_1.Validators.minLength(3)]),
            category: new forms_1.FormControl("Mobile", [forms_1.Validators.required]),
            description: new forms_1.FormControl("black", [forms_1.Validators.required, forms_1.Validators.minLength(3)]),
        });
    }
    EditAdComponent.prototype.onSubmit = function (obj) {
        /*let obj ={title:title, name:name, category:category,description:description};
            //this.prodList.push(obj);
           
        this.as.postAd(obj);*/
    };
    EditAdComponent.prototype.ngOnInit = function () { this.index = this.ar.snapshot.params['i.value']; };
    return EditAdComponent;
}());
EditAdComponent = __decorate([
    core_1.Component({
        selector: 'EditAdSelector',
        templateUrl: "./EditAdComponent.html",
        styleUrls: ["./EditAd.css"]
    }),
    __metadata("design:paramtypes", [AdvertisementService_1.AdvertisementService, router_1.ActivatedRoute])
], EditAdComponent);
exports.EditAdComponent = EditAdComponent;
//# sourceMappingURL=EditAdComponent.js.map