import {Component} from '@angular/core';

@Component({
    selector: 'HomeSelector',
    templateUrl: `./HomeComponent.html`,
    styleUrls: [`./homePage.css`]
})

export class HomeComponent {
    
}