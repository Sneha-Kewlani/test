import {Component} from '@angular/core';

@Component({
    selector: 'IndexPageSelector',
    template: `<NavBarSelector></NavBarSelector><HomeSelector></HomeSelector>`
})

export class IndexPageComponent {
    
}