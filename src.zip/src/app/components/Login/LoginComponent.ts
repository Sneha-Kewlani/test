import {Component} from '@angular/core';
import { AdvertisementService } from '../../services/AdvertisementService';

@Component({
    selector: 'LoginSelector',
    templateUrl: `./LoginComponent.html`,
    styleUrls: [`./Login.css`]
})

export class LoginComponent {

    constructor(private as:AdvertisementService ) {
        }
    onSubmit(username : any , password : any){
    console.log(username);
    console.log(password);
    this.as.login(username, password);
}

    
}