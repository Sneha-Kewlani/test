import {Component} from '@angular/core';

@Component({
    selector: 'NavBarSelector',
    templateUrl: `./NavBarComponent.html`,
    styleUrls: [`./NavBar.css`]
})

export class NavBarComponent {

    
    
}