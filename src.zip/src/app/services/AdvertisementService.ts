import { Injectable } from '@angular/core';
import {Http, Response, RequestOptions, Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()

export class AdvertisementService {

    constructor(private _http:Http){}
static Authkey:String;
    products: Array<any>=[];
    

    postAd(item:any){
        let url = "http://192.168.3.144:9000/postAd"; 
         let headers = new Headers();
        headers.append('auth-token', '5976ea511c0edf75e32798d4');
        headers.append('Content-Type', 'application/json');

        let options = new RequestOptions({ headers: headers });
        let jsonReq = {title: item.title, name:item.name, category: item.category, description:item.description};
        console.log(jsonReq);
        let obj =this._http.post(url, jsonReq, options).map((response: Response)=>response.json());
        obj.subscribe((data)=>console.log(data));

    }

        getAdvertisements() { 
        let url = "http://192.168.3.144:9000/posts"; 
        let headers = new Headers();
        headers.append('auth-token', '5976ea511c0edf75e32798d4');
        headers.append('Content-Type', 'application/json');
         let options = new RequestOptions({ headers: headers });


        let obj= this._http.get(url,options). map((response: Response)=>response.json()); 
         obj.subscribe((data)=>console.log(data));
         return obj;
       // console.log(obj);
    }

    getCategory(){
        let url = "http://192.168.3.144:9000/categories";
      
        let categoryObj= this._http.get(url).map((response:Response)=>response.json());
        return categoryObj;
    }

    deleteAdvertisement(id:any){
             let url = "http://192.168.3.144:9000/post?postId=";
        return this._http.delete(url+id).map((response:Response)=>response.json());
    }

    editAdvertisement(item:any,id:any){
        let url = "http://192.168.3.144:9000/postAd"; 
         let headers = new Headers();
        headers.append('auth-token', '5976ea511c0edf75e32798d4');
        headers.append('Content-Type', 'application/json');

        let options = new RequestOptions({ headers: headers });
        let jsonReq = {title: item.title, name:item.name, category: item.category, description:item.description};
        console.log(jsonReq);
        let obj =this._http.post(url, jsonReq, options).map((response: Response)=>response.json());
        obj.subscribe((data)=>console.log(data));

    }

        login(userName: any, password: any)
         {
        let url = "http://192.168.3.144:9000/login"; 
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        let options = new RequestOptions({ headers: headers });
        let jsonReq = { "userName": userName, "password": password };
        let adObj = this._http.post(url, jsonReq, options).map((response: Response) => response.json());
        adObj.subscribe((data) => {
            console.log(data);
            AdvertisementService.Authkey = data.data["auth-token"];
            console.log("in Auth Key variable", AdvertisementService.Authkey)
        });


         }

}